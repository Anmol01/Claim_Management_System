﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using CMS_Project;

public partial class ClaimDetails : System.Web.UI.Page 
{
    #region Function for Page Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Claim_Id"] == null)
        {
            Response.Redirect("login.aspx");
        }

        if (!IsPostBack)
        {
            using (Claim_Management_System dalObject = new Claim_Management_System())
            {
                DataTable dataTableObject = new DataTable();
                dataTableObject = dalObject.FunDataTableViewMore("usp_viewmore", Session["Claim_Id"].ToString());

                if (dataTableObject.Rows.Count > 0)
                {
                    firstNameTextBox.Text = dataTableObject.Rows[0][1].ToString();
                    lastNameTextBox.Text = dataTableObject.Rows[0][2].ToString();
                    dateOfBirthCalender.Text = dataTableObject.Rows[0][3].ToString().Split(' ')[0];
                    emailTextBox.Text = dataTableObject.Rows[0][4].ToString();
                    phoneTextBox.Text = dataTableObject.Rows[0][6].ToString();
                    addressTextArea.Text = dataTableObject.Rows[0][7].ToString();
                    nomineeTextBox.Text = dataTableObject.Rows[0][8].ToString();
                    insuranceTextBox.Text = dataTableObject.Rows[0][9].ToString();
                    maxinsurancetextbox.Text = dataTableObject.Rows[0][11].ToString();
                    ReqDateCalender.Text = dataTableObject.Rows[0][12].ToString().Split(' ')[0];
                    reasonTextBox.Text = dataTableObject.Rows[0][13].ToString();
                    claimAmountTextbox.Text = dataTableObject.Rows[0][14].ToString();
                    statusTextBox.Text = dataTableObject.Rows[0][15].ToString();

                    if (dataTableObject.Rows[0][5].ToString().Equals("M"))
                    {
                        Male.Checked = true;
                    }
                    else
                    {
                        Female.Checked = true;
                    }
                }
            }
        }
    }
    #endregion
    #region Function for Cancel Button
    protected void cancelButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("SearchClaim.aspx");
    }
    #endregion
    #region Function for Process Button
    protected void processButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("ClaimProcessing.aspx");
    }
    #endregion      
}