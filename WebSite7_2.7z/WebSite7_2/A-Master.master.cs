﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CMS_Project;
public partial class A_Master : System.Web.UI.MasterPage
{
    #region Function for Page Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Admin_Id"] != null)
        {
            Label1.Text = Session["Admin_Id"].ToString();
        }
        else
            Response.Redirect("login.aspx");
    }
    #endregion
    #region Function for Logout Button
    protected void Logout_Click(object sender, ImageClickEventArgs e)
    {
        Session.Abandon();
        Response.Redirect("login.aspx");
    }
    #endregion    
}
