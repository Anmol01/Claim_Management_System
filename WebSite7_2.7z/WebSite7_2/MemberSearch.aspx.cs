﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using CMS_Project;

public partial class MemberSearch : System.Web.UI.Page
{
    #region variables
    DataTable dataTableObject;
    string Member_Id = String.Empty;
    #endregion    
    #region Function for Paging in Detail View
    protected void OnPaging(object sender, DetailsViewPageEventArgs e)
    {
        memberSearchResults.PageIndex = e.NewPageIndex;
        memberSearchResults.DataBind();
        Member_Id = memberSearchResults.Rows[0].Cells[1].Text;
        Session["memberId"] = Member_Id;
    }
    #endregion    
    #region Function for Page Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Admin_Id"] == null)
        {
            Response.Redirect("login.aspx");
        }
        using (Claim_Management_System dalObject = new Claim_Management_System())
        {
            dataTableObject = dalObject.FunDataTable("select * from members_profile  order by cast(substring(mem_id, 2, len(mem_id) - 1) as int)");

            if (dataTableObject.Rows.Count > 0)
            {
                memberSearchResults.Visible = true;
                memberSearchResults.AutoGenerateRows = true;
                memberSearchResults.DataSource = dataTableObject;
                memberSearchResults.DataBind();

                if (!IsPostBack)
                {
                    Member_Id = memberSearchResults.Rows[0].Cells[1].Text;
                    Session["memberId"] = Member_Id;
                }

                message.Visible = false;
                updatemember.Visible = true;
            }
            else
            {
                memberSearchResults.Visible = false;
                message.Visible = true;
                message.Text = "No Record Found...";
                updatemember.Visible = false;
            }
        }
    }
    #endregion    
    #region Function for Search Button
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        using (Claim_Management_System dalObject = new Claim_Management_System())
        {
            dataTableObject = dalObject.FunDataTable("exec usp_memberDetails '" + memeberidtextbox.Text.ToString() + "'");

            if (dataTableObject.Rows.Count > 0)
            {
                memberSearchResults.Visible = true;
                memberSearchResults.AutoGenerateRows = true;
                memberSearchResults.DataSource = dataTableObject;
                memberSearchResults.DataBind();
                Member_Id = memberSearchResults.Rows[0].Cells[1].Text;
                Session["memberId"] = Member_Id;
                message.Visible = false;
                updatemember.Visible = true;
            }
            else
            {
                memberSearchResults.Visible = false;
                message.Visible = true;
                message.Text = "No Record Found...";
                updatemember.Visible = false;
            }
        }
    }
    #endregion   
    #region Function for Update Button
    protected void updatemember_Click(object sender, EventArgs e)
    {
        Response.Redirect("MemberProfileUpdate.aspx");
    }
    #endregion    
}